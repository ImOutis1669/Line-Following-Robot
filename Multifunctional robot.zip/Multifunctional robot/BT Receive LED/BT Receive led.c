/*
 * BT Receive LED.c
 *
 * Created: 16/03/2026 11:12:53
 * Author : ZEBED
 */ 
#define F_CPU 20E6
#include <avr/io.h>
#include <avr/interrupt.h>
#include <string.h>
#include <stdio.h>
#include <util/delay.h>
#define Baud_Rate 9600UL
#define Baud_Register_Value ((F_CPU / (16 * Baud_Rate))-1)
#define Red_LED PA0									// Red LED is on Port A, Pin 0
#define Green_LED PA1								// Green LED is on Port A, Pin 1
#define Blue_LED PA2								// Blue LED is on Port A, Pin 2
#define Yellow_LED PA3								// Yellow LED is on Port A, Pin 3

volatile char Rx_Char = 'S';

int main(void)
{
	DDRA = 1<<Red_LED | 1<<Yellow_LED | 1<<Blue_LED | 1<<Green_LED;
	
	UBRR0 = Baud_Register_Value;			// Set UART's baud to 9600 with F_CPU = 20 MHz
	UCSR0B = 1<<RXEN0 | 1<<RXCIE0;			// Receive enable, receive interrupt enable
	UCSR0C = 1<<UCSZ01 | 1<<UCSZ00;		// 8-bit data format
	
	DDRA = 1<<Green_LED | 1<<Red_LED | 1<<Blue_LED | 1<<Yellow_LED;		// Pin with green and red LED an output

	sei();                                   // Enable global interrupts
	
	while (1)
	{
	}
}

ISR(USART0_RX_vect)
{
	PORTA^=1<<Red_LED;
	Rx_Char = UDR0;
	if (Rx_Char == 'F')
	{
		PORTA |= 1<<Red_LED;
	}
	else if (Rx_Char == 'B')
	{
		PORTA |= 1<<Green_LED;
	}
	else if (Rx_Char == 'L')
	{
		PORTA |= 1<<Blue_LED;
	}
	else if (Rx_Char == 'R')
	{
		PORTA |= 1<<Yellow_LED;
	}
	else
	{
		PORTA &= ~(1<<Red_LED);
		PORTA &= ~(1<<Green_LED);
		PORTA &= ~(1<<Blue_LED);
		PORTA &= ~(1<<Yellow_LED);
	}
}