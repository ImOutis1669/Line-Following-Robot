/*
 * Joystick - LEDs.c
 *
 * Created: 04/02/2026 10:29:29
 * Author : ZEBED
 */ 

/*
This code uses joystick inputs to control LEDs
There are 4 LEDs representing 4 possible directions: Green (forwards), Red (backwards), Blue (left), Yellow (right)
The ADC is done for both the joystick x values and y values.
A deadzone of 50 is used to remove any incorrect changes in LEDs
Characterising the joystick gave central values of 515 on the x-axis and 529 on the y-axis
*/

#define F_CPU 20E6
#include <avr/io.h>
#include <util/delay.h>
#include <stdio.h>
#define deadzone 50
#define Red_LED PC0
#define Yellow_LED PC1
#define Blue_LED PC2
#define Green_LED PC3
char UART_Buffer[30];
volatile int ADC_Result = 0;
volatile int ADC_x = 0;
volatile int ADC_y = 0;

int ADC_Conversion()  // ADC conversion function
{
	ADCSRA |= 1<<ADSC;         // ADSC (starts conversion) bit set
	while(ADCSRA & 1<<ADSC);   // As long as ADSC high, stay in while loop
	return(ADC);
}

int main(void)
{
	
	// ADC initialisation
	ADMUX = 1<<REFS0;              // Sets Reference voltage and input to the ADC
	ADCSRA = 1<<ADEN | 1<<ADPS0 | 1<<ADPS2;  // Enables ADC and sets prescale
	DIDR0 = 0xFF;                            // Sets register DIDR off
	
	DDRC = 1<<Red_LED | 1<<Yellow_LED | 1<<Blue_LED | 1<<Green_LED;			// Set LED pins as outputs

	while (1)
	{
		
		// Read y axis values:
		ADMUX = 1<<REFS0;
		ADC_y = ADC_Conversion();
		
		ADMUX = 1<<REFS0 | 1<<MUX0;
		ADC_x = ADC_Conversion();
		
		// Joystick pushed forwards
		if (ADC_y < (560 - deadzone))
		{
			PORTC |= (1<<Green_LED);	// Green_LED on
			PORTC &= ~(1<<Red_LED);		// Red_LED off
		}
		// Joystick pushed backwards
		else if (ADC_y > (560 + deadzone))
		{
			PORTC |= (1<<Red_LED);			// Red_LED on
			PORTC &= ~(1<<Green_LED);		// Green_LED off
		}
		// defaults
		else
		{
			PORTC &= ~(1<<Red_LED);			// Red_LED off
			PORTC &= ~(1<<Green_LED);		// Green_LED off
		}
		
		// Joystick pushed left
		if (ADC_x < (515 - deadzone))
		{
			PORTC |= (1<<Blue_LED);	// Green_LED on
			PORTC &= ~(1<<Yellow_LED);		// Red_LED off
		}
		// Joystick pushed backwards
		else if (ADC_x > (515 + deadzone))
		{
			PORTC |= (1<<Yellow_LED);			// Red_LED on
			PORTC &= ~(1<<Blue_LED);		// Green_LED off
		}
		// defaults
		else
		{
			PORTC &= ~(1<<Yellow_LED);			// Red_LED off
			PORTC &= ~(1<<Blue_LED);		// Green_LED off
		}
	}
}



