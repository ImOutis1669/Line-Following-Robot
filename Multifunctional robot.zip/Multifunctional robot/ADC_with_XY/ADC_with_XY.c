/*
 * ADC_with_XY.c
 *
 * Created: 11/02/2026 11:24:24
 * Author : 230090767
 */ 

#include <avr/io.h>


int main(void)
{
    /* Replace with your application code */
    while (1) 
    {
    }
}

