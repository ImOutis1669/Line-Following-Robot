################################################################################
# Automatically-generated file. Do not edit or delete the file
################################################################################

Joystick ADC with X and Y.c

