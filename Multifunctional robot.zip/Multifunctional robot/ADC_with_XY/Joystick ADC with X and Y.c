/*
 * ADC_with_XY.c
 *
 * Created: 11/02/2026 11:24:24
 * Author : 230090767
 */ 

#define F_CPU 20E6
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include <string.h>
#include <stdio.h>

#define Compare 23828  // Compare value 
char UART_Buffer[30];
volatile int ADC_Result_X = 0;
volatile int ADC_Result_Y = 0;

// Define Baud rate
#define Baud_Rate 9600UL
#define Baud_Register_Value ((F_CPU / (16 * Baud_Rate))-1)

int ADC_Conversion()  // ADC conversion function
{
	ADCSRA |= 1 << ADSC;         // Start conversion
	while (ADCSRA & 1 << ADSC);  // Wait until conversion is finished
	return ADC;                  // Return the ADC result
}

void Transmit_Character(char C)
{
	while ((UCSR0A & 1 << UDRE0) == 0); // Wait for Data Register to be empty
	UDR0 = C; // Transmit the character
}

void Transmit_String(char String[])
{
	uint8_t String_Length = strlen(String); // Get the string length
	for (uint8_t Index = 0; Index < String_Length; Index++) // Loop through the string
	{
		Transmit_Character(String[Index]); // Transmit each character
	}
}

void ADC_Select_PA2(void)
{
	// Select PA2 (ADC2) as input
	ADMUX = (1 << REFS0) | (1 << MUX1); // MUX1 set for PA2 (ADC2)
}

void ADC_Select_PA3(void)
{
	// Select PA3 (ADC3) as input
	ADMUX = (1 << REFS0) | (1 << MUX1) | (1 << MUX0); // MUX1 + MUX2 set for PA3 (ADC3)
}

int main(void)
{
	// ADC initialization
	ADCSRA = 1 << ADEN | 1 << ADPS0 | 1 << ADPS2; // Enable ADC and set prescaler
	DIDR0 = 0xFF; // Disable digital input buffers for ADC pins

	// Set up UART baud rate
	UBRR0 = Baud_Register_Value; // Set UART baud rate
	UCSR0B = 1 << TXEN0; // Enable transmitter

	// Set up Timer1 for interrupt
	OCR1A = Compare; // Load compare value
	TCCR1B = 1 << WGM12 | 1 << CS12 | 1 << CS10; // CTC mode, prescale c/1024
	TIMSK1 = 1 << OCIE1A; // Enable output Compare Interrupts A

	sei(); // Enable global interrupts

	Transmit_String("Just reset..\r");
	Transmit_String("Initialising\r");

	while (1)
	{
		// Main loop can be left empty for now
	}
}

ISR(TIMER1_COMPA_vect)
{
	PORTD ^= 1 << Blue_LED; // Toggle Blue LED

	// Read ADC for X (PA2 - ADC2)
	ADC_Select_PA2();  // Select PA2 (ADC2)
	ADC_Result_X = ADC_Conversion();  // Store ADC result for X

	// Read ADC for Y (PA3 - ADC3)
	ADC_Select_PA3();  // Select PA3 (ADC3)
	ADC_Result_Y = ADC_Conversion();  // Store ADC result for Y

	// Format and send results via UART
	sprintf(UART_Buffer, "X = %d, Y = %d\r", ADC_Result_X, ADC_Result_Y);
	Transmit_String(UART_Buffer); // Send both X and Y values via UART
}
