/*
 * Dual motor control.c
 *
 * Created: 18/02/2026 10:58:39
 * Author : ZEBED
 */ 

#define F_CPU 20E6
#include <avr/io.h>
#include <util/delay.h>
#define Motor_1_PWM PD5			// Motor 1 PWM output on OC1A (PD5) - Speed control
#define Motor_2_PWM PD4			// Motor 2 PWM output on OC1A (PD5) - Speed control
#define DIR_1 PC0				// DIR1 (Motor 1 direction control) on PC0
#define DIR_2 PC1				// DIR1 (Motor 2 direction control) on PC1

int Width = 255;				// Sets PWM width - controlling motor speed

void forward()
{
	PORTC |= 1<<DIR_1;
	PORTC &= ~(1<<DIR_2);
}

void backward()
{
	PORTC |= 1<<DIR_2;
	PORTC &= ~(1<<DIR_1);
}

void left()
{
	PORTC |= 1<<DIR_1;
	PORTC |= 1<<DIR_2;
}

void right()
{
	PORTC &= ~(1<<DIR_1);
	PORTC &= ~(1<<DIR_2);
}

int main(void)
{
	// Make control pins outputs
	DDRD = 1<<Motor_1_PWM | 1<<Motor_2_PWM;
	DDRC = 1<<DIR_1 | 1<<DIR_2;
	
	// Load the width
	OCR1A = Width;
	OCR1B = Width;
	
	// Settings for 8-bit fast PWM, no prescale and set Blue LED to non-invertingPWM
	TCCR1A = 1<<WGM10 | 1<<COM1A1 | 1<<COM1B1; // sets COM1A1 to non inverting
	TCCR1B = 1<<WGM12 | 1<<CS10;

	while (1)
	{
		forward();
		_delay_ms(1500);
		backward();
		_delay_ms(1500);
		left();
		_delay_ms(1500);
		right();
		_delay_ms(1500);
	}
}


