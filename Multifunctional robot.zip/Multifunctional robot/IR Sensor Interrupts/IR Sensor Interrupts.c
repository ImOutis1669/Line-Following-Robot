/*
 * IR Sensor Interrupts.c
 *
 * Created: 04/02/2026 10:27:27
 * Author : ZEBED
 */ 

/*
This code uses interrupts to change LEDs based on IR sensors
IR sensors are connected to INT0 and INT1 (PD2 and PD3 on ATMEGA644PA)
When IR1 detects white, the Red_LED should be on. When IR1 detects black, the Green_LED should be on
When IR2 detects white, the Blue_LED should be on. When IR2 detects black, the Yellow_LED should be on
*/

#define F_CPU 20E6						//cpu frequency is 20MHz
#include <avr/io.h>						//AVR definitions
#include <avr/interrupt.h>				//Interrupt library
#define Red_LED PC0
#define Yellow_LED PC1
#define Blue_LED PC2
#define Green_LED PC3

int main (void)
{
	//Set INT0 and INT1 to trigger on any edge
	EICRA = 1<<ISC00 | 1<<ISC10;
	
	//Then enable INT0 and INT1 interrupt mask
	EIMSK = 1<<INT0 | 1<<INT1;
	
	DDRC = 1<<Red_LED | 1<<Yellow_LED | 1<<Blue_LED | 1<<Green_LED;			// Set LED pins as outputs
	
	// Set default LED states (when sensing black)
	PORTC |= (1<<Red_LED);			// Red_LED on
	PORTC &= ~(1<<Green_LED);		// Green_LED off
	PORTC |= (1<<Yellow_LED);		// Yellow_LED on
	PORTC &= ~(1<<Blue_LED);		// Blue_LED off

	//finally enable global interrupts
	sei();

	while (1)
	{
		asm("nop");
	}
}
/*-----------------------------------------------------------------------*/

ISR(INT0_vect)
{
	// Toggle Red and Green when IR1 senses a change
	PORTC ^= 1<<Red_LED;
	PORTC ^= 1<<Green_LED;
}


ISR(INT1_vect)
{
	// Toggle Yellow and Blue LED when IR2 senses a change
	PORTC ^= 1<<Yellow_LED;		// Yellow_LED on
	PORTC ^= 1<<Blue_LED;		// Blue_LED off
}
