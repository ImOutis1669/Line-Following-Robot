/*
 * Single motor control.c
 *
 * Created: 18/02/2026 10:19:50
 * Author : ZEBED
 */ 

#define F_CPU 20E6
#include <avr/io.h>
#include <util/delay.h>
#define Motor_PWM PD5			// PWM output on OC1A (PD5)
#define DIR_1 PC0

int Width = 255;				// Sets PWM width - controlling motor speed


int main(void)
{
	// Make L293D pins outputs
	DDRD = 1<<Motor_PWM;
	DDRC = 1<<DIR_1;
	
	// Load the width
	OCR1A = Width;

	// Settings for 8-bit fast PWM, no prescale and set Blue LED to non-invertingPWM
	TCCR1A = 1<<WGM10 | 1<<COM1A1; // sets COM1A1 to non inverting
	TCCR1B = 1<<WGM12 | 1<<CS10;

	while (1)
	{
		// Spin clockwise for 500ms
		PORTC |= 1<<DIR_1;
		_delay_ms(500);
		// Spin counter-clockwise for 500ms
		PORTC &= ~(1<<DIR_1);
		_delay_ms(500);
	}
}


