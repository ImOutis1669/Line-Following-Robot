/*
 * Bluetooth-Laptop LED.c
 *
 * Created: 25/02/2026 09:26:43
 * Author : ZEBED
 */ 

#include <avr/io.h>
#include <avr/interrupt.h>
#include <string.h>
#include <stdio.h>
#define F_CPU 20E6
#define Baud_Rate 9600UL
#define Baud_Register_Value ((F_CPU / (16 * Baud_Rate))-1)
#define Red_LED PC0

int main(void)
{
	DDRC |= 1<<Red_LED;
	UBRR0 = Baud_Register_Value;			// Set UART's baud to 9600 with F_CPU = 20 MHz
	UCSR0B = 1<<RXEN0 | 1<<RXCIE0;			// Receive enable, receive interrupt enable

	sei();                                   // Enable global interrupts
	
	

    while (1) 
    {
    }
}

ISR(USART0_RX_vect)
{
	static char Rx_Char;					// Variable to store UART data
	Rx_Char = UDR0;							// Read UART data
	if (Rx_Char == 'R')
	{
		PORTC |= 1<<Red_LED;				// Switch LED on if 'R'
	}
	else if (Rx_Char == 'r')
	{
		PORTC &= ~(1<<Red_LED);				// Switch LED off if 'r'
	}
}
