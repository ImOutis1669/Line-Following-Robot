/*
 * Bluetooth receive joyst.c
 *
 * Created: 04/03/2026 11:20:17
 * Author : ZEBED
 */ 

#define F_CPU 20E6
#include <avr/io.h>
#include <avr/interrupt.h>
#include <string.h>
#include <stdio.h>
#define Baud_Rate 9600UL
#define Baud_Register_Value ((F_CPU / (16 * Baud_Rate))-1)
#define Red_LED PA0									// Red LED is on Port A, Pin 0
#define Green_LED PA1								// Green LED is on Port A, Pin 1
#define Blue_LED PA2								// Blue LED is on Port A, Pin 2
#define Yellow_LED PA3								// Yellow LED is on Port A, Pin 3

int main(void)
{
	UBRR0 = Baud_Register_Value;			// Set UART's baud to 9600 with F_CPU = 20 MHz
	UCSR0B = 1<<RXEN0 | 1<<RXCIE0;			// Receive enable, receive interrupt enable
	
	DDRA = 1<<Green_LED | 1<<Red_LED | 1<<Blue_LED | 1<<Yellow_LED;		// Pin with green and red LED an output

	sei();                                   // Enable global interrupts
	
	while (1)
	{
	}
}

ISR(USART0_RX_vect)
{
	static char Rx_Char;					// Variable to store UART data
	Rx_Char = UDR0;							// Read UART data
	if (Rx_Char == 'F')
	{
		PORTA |= 1<<Green_LED;				// Switch LED on if 'R'
	}
	else if (Rx_Char == 'B')
	{
		PORTA |= 1<<Red_LED;	
	}
	else if (Rx_Char == 'L')
	{
		PORTA |= 1<<Yellow_LED;				// Switch LED on if 'G'
	}
	else if (Rx_Char == 'R')
	{
		PORTA |= 1<<Blue_LED;	
	}
}