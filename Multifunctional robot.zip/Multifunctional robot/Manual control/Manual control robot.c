/*
 * Manual control robot.c
 *
 * Created: 04/03/2026 09:08:04
 * Author : ZEBED
 */ 

#define F_CPU 20E6
#include <avr/io.h>
#include <avr/interrupt.h>
#include <string.h>
#include <stdio.h>
#include <util/delay.h>
#define Baud_Rate 9600UL
#define Baud_Register_Value ((F_CPU / (16 * Baud_Rate))-1)
#define Motor_1_PWM PD5			// Motor 1 PWM output on OC1A (PD5) - Speed control
#define Motor_2_PWM PD4			// Motor 2 PWM output on OC1A (PD5) - Speed control
#define DIR_1 PC0				// DIR1 (Motor 1 direction control) on PC0
#define DIR_2 PC1				// DIR1 (Motor 2 direction control) on PC1

int Width = 255;				// Sets PWM width - controlling motor speed
int stop = 0;

void forward()
{
	PORTC |= 1<<DIR_1;
	PORTC &= ~(1<<DIR_2);
}

void backward()
{
	PORTC |= 1<<DIR_2;
	PORTC &= ~(1<<DIR_1);
}

void left()
{
	PORTC |= 1<<DIR_1;
	PORTC |= 1<<DIR_2;
}

void right()
{
	PORTC &= ~(1<<DIR_1);
	PORTC &= ~(1<<DIR_2);
}

int main(void)
{
	UBRR0 = Baud_Register_Value;			// Set UART's baud to 9600 with F_CPU = 20 MHz
	UCSR0B = 1<<RXEN0 | 1<<RXCIE0;			// Receive enable, receive interrupt enable
	
	// Make control pins outputs
	DDRD = 1<<Motor_1_PWM | 1<<Motor_2_PWM;
	DDRC = 1<<DIR_1 | 1<<DIR_2;
	
	// Settings for 8-bit fast PWM, no prescale and set Blue LED to non-invertingPWM
	TCCR1A = 1<<WGM10 | 1<<COM1A1 | 1<<COM1B1; // sets COM1A1 to non inverting
	TCCR1B = 1<<WGM12 | 1<<CS10;

	sei();                                   // Enable global interrupts
	
	while (1)
	{
		
	}
	
}

ISR(USART0_RX_vect)
{
	// Set default movement speed
	
	
	static char Rx_Char;					// Variable to store UART data
	Rx_Char = UDR0;							// Read UART data
	if (Rx_Char == 'F')
	{
		forward();
		OCR1A = Width;
		OCR1B = Width;
	}
	else if (Rx_Char == 'B')
	{
		backward();
		OCR1A = Width;
		OCR1B = Width;
	}
	else if (Rx_Char == 'L')
	{
		left();
		OCR1A = Width;
		OCR1B = Width;
	}
	else if (Rx_Char == 'R')
	{
		right();
		OCR1A = Width;
		OCR1B = Width;
	}
	else if (Rx_Char == 's')   // joystick centered
	{
		OCR1A = 0;
		OCR1B = 0;
	}
	else
	{
		OCR1A = 0;
		OCR1B = 0;
	}
}