/*
 * URM37 Distance Beeper (ATmega644P, 20 MHz)
 *
 * URM37 V5.0 PWM trigger mode:
 * - Trigger a measurement with a brief LOW pulse on COMP/TRIG
 * - Read distance as LOW pulse width on ECHO: 50us = 1cm :contentReference[oaicite:1]{index=1}
 * - 50000us indicates invalid/out of range :contentReference[oaicite:2]{index=2}
 *
 * Connections:
 * URM37 VCC -> 5V
 * URM37 GND -> GND
 * URM37 COMP/TRIG -> PD2 (TRIG_PIN)
 * URM37 ECHO      -> PD3 (ECHO_PIN)
 * BUZZER (active) -> PD5 (BUZZER_PIN)  HIGH = sound
 */

#define F_CPU 20E6

#include <avr/io.h>
#include <util/delay.h>
#include <stdint.h>

#define TRIG_PIN    PD2
#define ECHO_PIN    PD3
#define BUZZER_PIN  PD5

#define MICROSECONDS_PER_CM   50UL
#define INVALID_PULSE_WIDTH   50000UL  // invalid reading 

// Beep is silent at/above this distance
#define MAX_DISTANCE_CM       15U

// -------- variable delay helpers (compile-safe) --------
static void delay_ms_var(uint16_t ms)
{
    while (ms--) _delay_ms(1);
}

// -------- IO init --------
static void io_init(void)
{
    // TRIG output, BUZZER output
    DDRD |= (1 << TRIG_PIN) | (1 << BUZZER_PIN);

    // ECHO input
    DDRD &= ~(1 << ECHO_PIN);

    // Idle states
    PORTD |=  (1 << TRIG_PIN);      // URM37 examples keep TRIG idle HIGH :contentReference[oaicite:4]{index=4}
    PORTD &= ~(1 << BUZZER_PIN);    // buzzer off
}

// -------- URM37 PWM measurement --------
// Returns ECHO LOW pulse width in microseconds (approx), or INVALID_PULSE_WIDTH if invalid/timeout
static uint32_t urm37_measure_echo_low_us(void)
{
    uint32_t count = 0;

    // Trigger: brief LOW pulse then back HIGH :contentReference[oaicite:5]{index=5}
    PORTD &= ~(1 << TRIG_PIN);
    _delay_us(10);
    PORTD |= (1 << TRIG_PIN);

    // Wait for ECHO to go LOW (start of LOW pulse)
    // If it never goes LOW, we timeout
    while (PIND & (1 << ECHO_PIN))
    {
        _delay_us(1);
        if (++count >= INVALID_PULSE_WIDTH) return INVALID_PULSE_WIDTH;
    }

    // Measure LOW pulse width
    count = 0;
    while (!(PIND & (1 << ECHO_PIN)))
    {
        _delay_us(1);
        if (++count >= INVALID_PULSE_WIDTH) return INVALID_PULSE_WIDTH;
    }

    return count;
}

static uint16_t urm37_distance_cm(void)
{
    uint32_t low_us = urm37_measure_echo_low_us();

    if (low_us >= INVALID_PULSE_WIDTH)
        return MAX_DISTANCE_CM; // treat invalid as far/silent

    uint16_t cm = (uint16_t)(low_us / MICROSECONDS_PER_CM); // 50us per cm :contentReference[oaicite:6]{index=6}
    if (cm > MAX_DISTANCE_CM) cm = MAX_DISTANCE_CM;
    return cm;
}

// -------- Beep mapping --------
// distance -> beep period (ms): close=fast, far=slow, far enough=silent
static uint16_t distance_to_period_ms(uint16_t d_cm)
{
    const uint16_t FAST_MS = 60;    // close
    const uint16_t SLOW_MS = 700;   // far (but still < MAX_DISTANCE)

    if (d_cm >= MAX_DISTANCE_CM) return 0; // silent

    if (d_cm < 1) d_cm = 1;

    // Linear map: 1..MAX -> FAST..SLOW
    uint32_t span = (uint32_t)(SLOW_MS - FAST_MS);
    uint32_t period = (uint32_t)FAST_MS +
                      (span * (uint32_t)(d_cm - 1)) / (uint32_t)(MAX_DISTANCE_CM - 1);

    return (uint16_t)period;
}

static void beep_once(uint16_t period_ms)
{
    uint16_t half = period_ms / 2;

    PORTD |= (1 << BUZZER_PIN);
    delay_ms_var(half);

    PORTD &= ~(1 << BUZZER_PIN);
    delay_ms_var(half);
}

int main(void)
{
    io_init();

    while (1)
    {
        uint16_t d = urm37_distance_cm();
        uint16_t period = distance_to_period_ms(d);

        if (period == 0)
        {
            // silent but keep sampling
            delay_ms_var(80);
        }
        else
        {
            // beep once; next loop re-samples so rate follows distance
            beep_once(period);
        }
    }
}