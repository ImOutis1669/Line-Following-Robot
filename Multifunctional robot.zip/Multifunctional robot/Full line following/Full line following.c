/*
 * Full line following.c
 *
 * Created: 17/02/2026 22:40:01
 * Author : ZEBED
 */ 

/*
Line following mode subsystem:
-Calls functions for movement directions - the same function scan then be called when implementing remote control
-When both sensors detect black, robot moves forwards
-When left sensor detects black and right detects white, move right 
-When left sensor detects white and right detects black, move left
*/

#define F_CPU 20E6
#include <avr/io.h>
#include <util/delay.h>
#define Motor_1_PWM PD5			// Motor 1 PWM output on OC1A (PD5) - Speed control
#define Motor_2_PWM PD4			// Motor 2 PWM output on OC1A (PD5) - Speed control
#define DIR_1 PC0				// DIR1 (Motor 1 direction control) on PC0
#define DIR_2 PC1				// DIR1 (Motor 2 direction control) on PC1
#define IR_Left PD2				// IR sensor 1 is on PD2
#define IR_Right PD3				// IR sensor 2 is on PD3
int Width = 235;				// Sets PWM width - controlling motor speed
int stop = 0;

void forward()					// Set motor directions to move forwards
{
	PORTC |= 1<<DIR_1;
	PORTC &= ~(1<<DIR_2);
}

void backward()					// Set motor directions to move backwards
{
	PORTC |= 1<<DIR_2;
	PORTC &= ~(1<<DIR_1);
}

void left()						// Set motor directions to move left
{
	PORTC |= 1<<DIR_1;
	PORTC |= 1<<DIR_2;
}

void right()					// Set motor directions to move right
{
	PORTC &= ~(1<<DIR_1);
	PORTC &= ~(1<<DIR_2);
}

int main (void)
{
	
	// Make control pins outputs
	DDRD = 1<<Motor_1_PWM | 1<<Motor_2_PWM;
	DDRC = 1<<DIR_1 | 1<<DIR_2;
	
	// Settings for 8-bit fast PWM, no prescale, non inverting
	TCCR1A = 1<<WGM10 | 1<<COM1A1 | 1<<COM1B1; // sets COM1A1 to non inverting
	TCCR1B = 1<<WGM12 | 1<<CS10;
	
	while (1)
	{
		// Load the width
		OCR1A = Width;
		OCR1B = Width;
		if (!(PIND & (1<<IR_Left | 1<<IR_Right)))
		{
			// Load the width
			OCR1A = Width;
			OCR1B = Width;
			// Both IR sees black -> go forwards
			forward();
			
		}
		else if (!(PIND & (1<<IR_Left)))
		{
			// Load the width
			OCR1A = Width;
			OCR1B = Width;
			// Left = Black, Right = White, go left
			left();
		}
		else if (!(PIND & (1<<IR_Right)))
		{
			// Load the width
			OCR1A = Width;
			OCR1B = Width;
			// Left = White, Right = Black, go right
			right();
		}
		else if ((PIND & (1<<IR_Left | 1<<IR_Right)))
		{
			OCR1A = stop;
			OCR1B = stop;
			_delay_ms(500);
		}

	}
}