/*
 * Line following.c
 *
 * Created: 17/02/2026 18:11:37
 * Author : ZEBED
 */ 

/* 
Code moves a singular motor. When the surface is black, the motor spins anti-clockwise, when it's white, the direction is reversed 
*/

#define F_CPU 20E6				// Clock frequency is 20MHz
#include <avr/io.h>				// AVR definitions
#include <avr/interrupt.h>		// Interrupt library
#define IR_1 PD2				// IR sensor 1 is on PD2
#define Motor_PWM PD5			// PWM output on OC1A (PD5)
#define DIR_1 PC0				// Direction control for motor 1 

int Width = 250;				// Sets PWM width - controlling motor speed

int main (void)
{
	
	// Make direction pins outputs
	DDRD = 1<<Motor_PWM;
	DDRC = 1<<DIR_1;
	
	// Load the width
	OCR1A = Width;


	// Settings for 8-bit fast PWM, no prescale and set Blue LED to non-invertingPWM
	TCCR1A = 1<<WGM10 | 1<<COM1A1; // sets COM1A1 to non inverting
	TCCR1B = 1<<WGM12 | 1<<CS10;
	
	while (1)
	{
		/* Sensor 1 detection logic - controls left motor */
		if (!(PIND & (1<<IR_1)))
		{
			// When white, spin clockwise
			PORTC |= 1<<DIR_1;
		}
		else
		{
			// When black spin anti-clockwise
			PORTC &= ~(1<<DIR_1);
		}
	}
}



