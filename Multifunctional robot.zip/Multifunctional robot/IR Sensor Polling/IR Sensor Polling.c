/*
 * IR Sensor Polling.c
 *
 * Created: 04/02/2026 10:28:19
 * Author : ZEBED
 */ 


/* 
This code uses a singular IR Sensor to light a red and a green LED:
When IR_1 sensor detects black, the Red_LED is on and Green_LED is off. When the sensor detects white, the Red_LED is off and the Green_LED is on.
*/

#define F_CPU 20E6						// Clock frequency is 20MHz
#include <avr/io.h>						// AVR definitions
#define IR_1 PD2						// IR sensor 1 is on PD2
#define Red_LED PC0
#define Green_LED PC3


int main (void)
{
	DDRC = 1<<Red_LED | 1<<Green_LED;	// Set LED pins as outputs
	
	while (1)
	{
		/* Sensor 1 detection logic - controls Red/Green */
		if ((PIND & (1<<IR_1)) == 0)
		{
			// IR sees black
			PORTC |= (1<<Red_LED);			// Red_LED on
			PORTC &= ~(1<<Green_LED);		// Green_LED off
		}
		else
		{
			// IR sees white
			PORTC &= ~(1<<Red_LED);			// Red_LED off
			PORTC |= (1<<Green_LED);		// Green_LED on
		}
	}
}
