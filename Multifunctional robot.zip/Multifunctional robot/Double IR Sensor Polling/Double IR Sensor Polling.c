/*
 * Double IR Sensor Polling.c
 *
 * Created: 11/02/2026 18:28:51
 * Author : ZEBED
 */ 


/* 
This code uses IR sensors to control LEDs.

*/

#define F_CPU 20E6						// Clock frequency is 20MHz
#include <avr/io.h>						// AVR definitions
#include <avr/interrupt.h>				// Interrupt library
#define IR_Left PD2						// IR sensor 1 is on PD2
#define IR_Right PD3					// IR sensor 2 is on PD3
#define Red_LED PC0
#define Yellow_LED PC1
#define Blue_LED PC2
#define Green_LED PC3


int main (void)
{
	DDRC = 1<<Red_LED | 1<<Yellow_LED | 1<<Blue_LED | 1<<Green_LED;	// Set LED pins as outputs

	
	while (1)
	{
		if (!(PIND & (1<<IR_Left | 1<<IR_Right)))
		{
			// Both IR sees black -> go forwards
			PORTC |= (1<<Green_LED);			// Green on (go forwards)								
			PORTC &= ~(1<<Red_LED);				// Red off
			PORTC &= ~(1<<Yellow_LED);			// Yellow off
			PORTC &= ~(1<<Blue_LED);			// Blue off
		}
		else if (!(PIND & (1<<IR_Left)))
		{
			// Left = Black, Right = White, go left
			PORTC |= (1<<Yellow_LED);		// Yellow on (turn left)
			PORTC &= ~(1<<Red_LED);			// Red off
			PORTC &= ~(1<<Green_LED);		// Green off
			PORTC &= ~(1<<Blue_LED);		// Blue off
		}
		else if (!(PIND & (1<<IR_Right)))
		{
			// Left = White, Right = Black, go right
			PORTC |= (1<<Blue_LED);			// Blue on (Turn right)
			PORTC &= ~(1<<Red_LED);			// Red off
			PORTC &= ~(1<<Green_LED);		// Green off
			PORTC &= ~(1<<Yellow_LED);		// Yellow off
		}
		else
		{
			PORTC |= (1<<Red_LED);			// Red on (Stop)
			PORTC &= ~(1<<Green_LED);		// Green off
			PORTC &= ~(1<<Yellow_LED);		// Yellow off
			PORTC &= ~(1<<Blue_LED);		// Blue off
		}
	}
}

