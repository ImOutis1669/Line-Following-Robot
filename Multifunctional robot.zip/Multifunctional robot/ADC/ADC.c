/*
 * ADC.c
 *
 * Created: 11/02/2026 09:26:18
 * Author : ZEBED
 */ 

#define F_CPU 20E6
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include <string.h>
#include <stdio.h>
#define Compare 23828								// Compare value for 1.22s
#define Green_LED PB4								// Green LED is on PortB bit 4
#define Blue_LED PD4								// Blue LED is on PortD bit 4
#define Red_LED PB3
char UART_Buffer[30];
volatile int ADC_Result = 0;


//Define Baud rate, UL tells complier to treat value as long unisgned integer, 32 bits
// This is needed for calculation that follows so the compiler doesnt default to 16-bits
#define Baud_Rate 9600UL
#define Baud_Register_Value ((F_CPU / (16 * Baud_Rate))-1)

int ADC_Conversion()  // ADC conversion function
{
	ADCSRA |= 1<<ADSC;         // ADSC (starts conversion) bit set
	while(ADCSRA & 1<<ADSC);   // As long as ADSC high, stay in while loop
	return(ADC);
}

void Transmit_Character(char C)
{
	while((UCSR0A & 1<<UDRE0) == 0);							// Wait for Data Register to be empty
	UDR0 = C;													// Transmit the character passed to the function
}

void Transmit_String(char String[])
{
	uint8_t String_Length = strlen(String);						// Obtain string's length
	for (uint8_t Index = 0; Index < String_Length; Index++)		// Loop through the string
	{
		Transmit_Character(String[Index]);						// Transmit a character
	}
}


int main(void)
{
	
	// ADC initialisation
	ADMUX = 1<<REFS0 | 1<<MUX1;              // Sets Reference voltage and input to the ADC  - This is for port PA2
	ADCSRA = 1<<ADEN | 1<<ADPS0 | 1<<ADPS2;  // Enables ADC and sets prescale
	DIDR0 = 0xFF;                            // Sets register DIDR off

	
	DDRB = 1<<Green_LED | 1<<Red_LED;					// Pin with green and red LED an output
	DDRD = 1<<Blue_LED;


	UBRR0 = Baud_Register_Value;			// Set UART's baud to 9600 with F_CPU = 20 MHz
	UCSR0B = 1<<TXEN0;						// Transmitter enable


	OCR1A = Compare;								// Load compare value
	TCCR1B	= 1<<WGM12 | 1<<CS12 | 1<<CS10;			// CTC mode, prescale c/1024
	TIMSK1 = 1<<OCIE1A;								// Enable output Compare Interrupts A
	
	sei();											// Enable global interrupts

	Transmit_String("Just reset..\r");
	Transmit_String("240235398\r");

	while (1)
	{
	}
}

ISR(TIMER1_COMPA_vect)
{
	PORTD ^= 1<<Blue_LED;
	//ADC_Conversion();				// Call ADC conversion
	ADC_Result = ADC_Conversion();	// Read the ADC
	sprintf(UART_Buffer, "ADC Result = %d \r", ADC_Result); // Build string with sprintf() and stores into UART_Buffer{}
	Transmit_String(UART_Buffer);							// Transmit the contents of UART_Buffer{} with Transmit_string()										// Increments ACD_Result
	if ((ADC_Result > 255) && (ADC_Result < 512))
	{
		PORTB |= 1<<Red_LED;						// Toggle red LED on
		PORTB &= ~(1<<Green_LED);						// Toggle green LED off
	}
	else if ((ADC_Result > 511) && (ADC_Result < 768))
	{
		PORTB |= 1<<Green_LED;						// Toggle green LED on
		PORTB &= ~(1<<Red_LED);						// Toggle red LED off
	}
	else if (ADC_Result > 767)
	{
		PORTB |= (1<<Green_LED | 1<<Red_LED);						// Toggle green and red LED on
	}
	else
	{
		PORTB &= ~(1<<Green_LED | 1<<Red_LED);						// Toggle green and red LED off
	}


}


