/*
 * Joystick xy control.c
 *
 * Created: 18/02/2026 13:33:56
 * Author : ZEBED
 */ 

#define F_CPU 20E6
#include <avr/io.h>
#include <util/delay.h>
#define Motor_1_PWM PD5			// Motor 1 PWM output on OC1A (PD5) - Speed control
#define Motor_2_PWM PD4			// Motor 2 PWM output on OC1A (PD5) - Speed control
#define DIR_1 PC0				// DIR1 (Motor 1 direction control) on PC0
#define DIR_2 PC1				// DIR1 (Motor 2 direction control) on PC1

int Width = 255;				// Sets PWM width - controlling motor speed
int stop = 0;
volatile int ADC_Result_X = 0;
volatile int ADC_Result_Y = 0;

int ADC_Conversion()  // ADC conversion function
{
	ADCSRA |= 1<<ADSC;         // ADSC (starts conversion) bit set
	while(ADCSRA & 1<<ADSC);   // As long as ADSC high, stay in while loop
	return(ADC);
}

void forward()					// Set motor directions to move forwards
{
	PORTC |= 1<<DIR_1;
	PORTC &= ~(1<<DIR_2);
}

void backward()					// Set motor directions to move backwards
{
	PORTC |= 1<<DIR_2;
	PORTC &= ~(1<<DIR_1);
}

void left()						// Set motor directions to move left
{
	PORTC |= 1<<DIR_1;
	PORTC |= 1<<DIR_2;
}

void right()					// Set motor directions to move right
{
	PORTC &= ~(1<<DIR_1);
	PORTC &= ~(1<<DIR_2);
}


void ADC_Select_PA2()
{
	// Select PA2 (ADC2) as input
	ADMUX = (1 << REFS0) | (1 << MUX1); // MUX1 set for PA2 (ADC2)
}

void ADC_Select_PA3()
{
	// Select PA3 (ADC3) as input
	ADMUX = (1 << REFS0) | (1 << MUX1) | (1 << MUX0); // MUX1 + MUX2 set for PA3 (ADC3)
}


int main(void)
{
	
	// ADC initialisation
	ADCSRA = 1<<ADEN | 1<<ADPS0 | 1<<ADPS2;  // Enables ADC and sets prescale
	DIDR0 = 0xFF;                            // Sets register DIDR off
	
	// Make control pins outputs
	DDRD = 1<<Motor_1_PWM | 1<<Motor_2_PWM;
	DDRC = 1<<DIR_1 | 1<<DIR_2;
	
	// Settings for 8-bit fast PWM, no prescale
	TCCR1A = 1<<WGM10 | 1<<COM1A1 | 1<<COM1B1; // sets COM1A1 & COM1B1 to non inverting
	TCCR1B = 1<<WGM12 | 1<<CS10;

	while (1)
	{
		// Read joystick x values
		ADC_Select_PA2();					// change ADC to read x values
		ADC_Conversion();					// throwaway conversion
		ADC_Result_X = ADC_Conversion();	// store x value

		// Read joystick y values
		ADC_Select_PA3();					// change ADC to read y values
		ADC_Conversion();					// throwaway conversion
		ADC_Result_Y = ADC_Conversion();	// store y value

		// Set default movement speed
		OCR1A = Width;
		OCR1B = Width;
		
		if (ADC_Result_X > 600)				// Joystick pushed forwards
		{
			forward();
		}
		else if (ADC_Result_X < 450)		// Joystick pushed backwards
		{
			backward();
		}
		else if (ADC_Result_Y > 600)		// Joystick pushed left
		{
			left();
		}
		else if (ADC_Result_Y < 450)		// Joystick pushed right
		{
			right();
		}
		else								// Joystick central
		{
			OCR1A = stop;
			OCR1B = stop;
		}
	}

}



