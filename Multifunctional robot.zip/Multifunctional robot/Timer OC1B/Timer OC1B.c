/*
 * Timer OC1B.c
 *
 * Created: 11/03/2026 10:16:15
 * Author : ZEBED
 */ 

#define F_CPU 20E6
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

#define Compare 62499								// Compare value for 0.2s


#define Green_LED PB4								// Green LED is on PortB bit 4
#define Blue_LED PD4								// Blue LED is on PortD bit 4

int main(void)
{
	DDRB |= 1<<Green_LED;							// Pin with green LED an output
	DDRD |= 1<<Blue_LED;							// Pin with blue LED an output
	
	OCR1A = Compare;								// Load compare value
	TCCR1B	= 1<<WGM12 | 1<<CS11 | 1<<CS10;			// CTC mode, prescale c/64
	TIMSK1 = 1<<OCIE1A;								// Enable output Compare Interrupts A
	
	sei();											// Enable global interrupts
	
	while (1)
	{
		PORTB ^= 1<<Green_LED;						// Toggle green LED
		_delay_ms(500);								// 500ms delay
	}
}

ISR(TIMER1_COMPA_vect)
{
	PORTD ^= 1<<Blue_LED;							// Toggle Blue LED
}
