/*
 * Bluetooth transmission.c
 *
 * Created: 04/03/2026 21:38:58
 * Author : ZEBED
 */ 

#define F_CPU 20E6
#include <avr/io.h>
#include <util/delay.h>
#include <string.h>
#include <stdio.h>

char UART_Buffer[30];
int ADC_Result = 0;



//Define Baud rate, UL tells complier to treat value as long unisgned integer, 32 bits
// This is needed for calculation that follows so the compiler doesnt default to 16-bits
#define Baud_Rate 9600UL
#define Baud_Register_Value ((F_CPU / (16 * Baud_Rate))-1)

void Transmit_Character(char C)
{
	while((UCSR0A & 1<<UDRE0) == 0);							// Wait for Data Register to be empty
	UDR0 = C;													// Transmit the character passed to the function
}

void Transmit_String(char String[])
{
	uint8_t String_Length = strlen(String);						// Obtain string's length
	for (uint8_t Index = 0; Index < String_Length; Index++)		// Loop through the string
	{
		Transmit_Character(String[Index]);						// Transmit a character
	}
}

int main(void)
{
	UBRR0 = Baud_Register_Value;			// Set UART's baud to 9600 with F_CPU = 20 MHz
	UCSR0B = 1<<TXEN0;						// Transmitter enable

	while (1)
	{
		 Transmit_Character('R');
		 _delay_ms(500);

		 Transmit_Character('r');
		 _delay_ms(500);
		
	}
}
