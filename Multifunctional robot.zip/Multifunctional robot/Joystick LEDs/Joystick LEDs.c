/*
 * Joystick LEDs.c
 *
 * Created: 18/03/2026 10:59:18
 * Author : ZEBED
 */ 
#define F_CPU 20E6
#include <avr/io.h>
#include <util/delay.h>
#define Red PC0
#define green PC1
#define Blue PC2
#define Yellow PC3

volatile int ADC_Result_X = 0;
volatile int ADC_Result_Y = 0;

int ADC_Conversion()  // ADC conversion function
{
	ADCSRA |= 1<<ADSC;         // ADSC (starts conversion) bit set
	while(ADCSRA & 1<<ADSC);   // As long as ADSC high, stay in while loop
	return(ADC);
}

void ADC_Select_PA2()
{
	// Select PA2 (ADC2) as input
	ADMUX = (1 << REFS0) | (1 << MUX1); // MUX1 set for PA2 (ADC2)
}

void ADC_Select_PA3()
{
	// Select PA3 (ADC3) as input
	ADMUX = (1 << REFS0) | (1 << MUX1) | (1 << MUX0); // MUX1 + MUX2 set for PA3 (ADC3)
}


int main(void)
{
	DDRC = 1<<Red | 1<<Blue | 1<<green | 1<<Yellow;
	// ADC initialisation
	ADCSRA = 1<<ADEN | 1<<ADPS0 | 1<<ADPS2;  // Enables ADC and sets prescale
	DIDR0 = 0xFF;                            // Sets register DIDR off
	
	// Settings for 8-bit fast PWM, no prescale
	TCCR1A = 1<<WGM10 | 1<<COM1A1 | 1<<COM1B1; // sets COM1A1 & COM1B1 to non inverting
	TCCR1B = 1<<WGM12 | 1<<CS10;

	while (1)
	{
		// Read joystick x values
		ADC_Select_PA2();					// change ADC to read x values
		ADC_Conversion();					// throwaway conversion
		ADC_Result_X = ADC_Conversion();	// store x value

		// Read joystick y values
		ADC_Select_PA3();					// change ADC to read y values
		ADC_Conversion();					// throwaway conversion
		ADC_Result_Y = ADC_Conversion();	// store y value
		
		if (ADC_Result_X > 600)				// Joystick pushed forwards
		{
			PORTC |= 1<<Red;
		}
		else if (ADC_Result_X < 450)		// Joystick pushed backwards
		{
			PORTC |= 1<<green;
		}
		else if (ADC_Result_Y > 600)		// Joystick pushed left
		{
			PORTC |= 1<<Blue;
		}
		else if (ADC_Result_Y < 450)		// Joystick pushed right
		{
			PORTC |= 1<<Yellow;
		}
		else								// Joystick central
		{
			PORTC &= ~(1<<Red);
			PORTC &= ~(1<<green);
			PORTC &= ~(1<<Blue);
			PORTC &= ~(1<<Yellow);
		}
	}

}





