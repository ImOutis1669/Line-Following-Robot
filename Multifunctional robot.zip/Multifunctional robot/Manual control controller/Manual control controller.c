/*
 * Manual control controller.c
 *
 * Created: 04/03/2026 09:27:23
 * Author : ZEBED
 */ 


#define F_CPU 20E6
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include <string.h>
#include <stdio.h>
#define Compare 3905								// Compare value for 0.2s
#define Red PD5
char UART_Buffer[30];
volatile int ADC_Result = 0;

//Define Baud rate, UL tells complier to treat value as long unisgned integer, 32 bits
// This is needed for calculation that follows so the compiler doesnt default to 16-bits
#define Baud_Rate 9600UL
#define Baud_Register_Value ((F_CPU / (16 * Baud_Rate))-1)

volatile int ADC_Result_X = 0;
volatile int ADC_Result_Y = 0;

void Transmit_Character(char C)
{
	while((UCSR0A & 1<<UDRE0) == 0);							// Wait for Data Register to be empty
	UDR0 = C;													// Transmit the character passed to the function
}

int ADC_Conversion()  // ADC conversion function
{
	ADCSRA |= 1<<ADSC;         // ADSC (starts conversion) bit set
	while(ADCSRA & 1<<ADSC);   // As long as ADSC high, stay in while loop
	return(ADC);
}

void ADC_Select_PA2()
{
	// Select PA2 (ADC2) as input
	ADMUX = (1 << REFS0) | (1 << MUX1); // MUX1 set for PA2 (ADC2)
}

void ADC_Select_PA3()
{
	// Select PA3 (ADC3) as input
	ADMUX = (1 << REFS0) | (1 << MUX1) | (1 << MUX0); // MUX1 + MUX2 set for PA3 (ADC3)
}

int main(void)
{
	// ADC initialization
	ADCSRA = 1 << ADEN | 1 << ADPS0 | 1 << ADPS2; // Enable ADC and set prescaler
	DIDR0 = 0xFF; // Disable digital input buffers for ADC pins
	
	UBRR0 = Baud_Register_Value;			// Set UART's baud to 9600 with F_CPU = 20 MHz
	UCSR0B = 1<<TXEN0;						// Transmitter enable

	OCR1A = Compare;								// Load compare value
	TCCR1B	= 1<<WGM12 | 1<<CS12 | 1<<CS10;			// CTC mode, prescale c/1024
	TIMSK1 = 1<<OCIE1A;								// Enable output Compare Interrupts A
	
	sei();											// Enable global interrupts

	while (1)
	{
	}
}

ISR(TIMER1_COMPA_vect)
{
	// Read joystick x values
	ADC_Select_PA2();					// change ADC to read x values
	ADC_Conversion();					// throwaway conversion
	ADC_Result_X = ADC_Conversion();	// store x value

	// Read joystick y values
	ADC_Select_PA3();					// change ADC to read y values
	ADC_Conversion();					// throwaway conversion
	ADC_Result_Y = ADC_Conversion();	// store y value
	
	if (ADC_Result_X > 600)				// Joystick pushed forwards
	{
		Transmit_Character('F');
	}
	else if (ADC_Result_X < 450)		// Joystick pushed backwards
	{
		Transmit_Character('B');
	}
	else if (ADC_Result_Y > 600)		// Joystick pushed left
	{
		Transmit_Character('L');
	}
	else if (ADC_Result_Y < 450)		// Joystick pushed right
	{
		Transmit_Character('R');
	}
	else 
	{
		Transmit_Character('s');
	}
}


