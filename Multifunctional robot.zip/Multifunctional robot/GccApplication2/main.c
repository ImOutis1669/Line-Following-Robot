/*
 * GccApplication2.c
 *
 * Created: 25/02/2026 20:29:01
 * Author : Outis
 */ 

#include <avr/io.h>


int main(void)
{
    /* Replace with your application code */
    while (1) 
    {
    }
}

