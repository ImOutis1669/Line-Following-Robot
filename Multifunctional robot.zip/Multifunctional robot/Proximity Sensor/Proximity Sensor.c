#define F_CPU 20000000UL

#include <avr/io.h>
#include <util/delay.h>

#define TRIG_PIN    PB3
#define ECHO_PIN    PB4
#define BUZZER_PIN  PB1

#define MICROSECONDS_PER_CM   15UL
#define INVALID_PULSE_WIDTH   50000UL
#define MAX_DISTANCE_CM       60U

static unsigned long measure_pulse_us(void)
{
	unsigned long count_us = 0;

	PORTB |= (1 << TRIG_PIN);

	PORTB &= ~(1 << TRIG_PIN);
	_delay_us(10);
	PORTB |= (1 << TRIG_PIN);

	while (PINB & (1 << ECHO_PIN))
	{
	}

	while (!(PINB & (1 << ECHO_PIN)))
	{
		_delay_us(1);
		count_us++;

		if (count_us >= INVALID_PULSE_WIDTH)
		return INVALID_PULSE_WIDTH;
	}

	return count_us;
}

static unsigned int measure_distance_cm(void)
{
	unsigned long low_us = measure_pulse_us();

	if (low_us >= INVALID_PULSE_WIDTH)
	return MAX_DISTANCE_CM;

	return (unsigned int)(low_us / MICROSECONDS_PER_CM);
}

static unsigned int distance_to_period_ms(unsigned int d_cm)
{
	const unsigned int FAST_MS = 60;
	const unsigned int SLOW_MS = 700;

	if (d_cm >= MAX_DISTANCE_CM)
	return 0;

	if (d_cm < 1)
	d_cm = 1;

	unsigned long span = (unsigned long)(SLOW_MS - FAST_MS);
	unsigned long period = FAST_MS + (span * (d_cm - 1)) / (MAX_DISTANCE_CM - 1);

	return (unsigned int)period;
}

static void delay_variable_ms(unsigned int ms)
{
	while (ms--)
	{
		_delay_ms(1);
	}
}

static void beep_once(unsigned int period_ms)
{
	PORTB |= (1 << BUZZER_PIN);
	delay_variable_ms(period_ms / 2);

	PORTB &= ~(1 << BUZZER_PIN);
	delay_variable_ms(period_ms / 2);
}

int main(void)
{
	DDRB |= (1 << TRIG_PIN);
	DDRB |= (1 << BUZZER_PIN);
	DDRB &= ~(1 << ECHO_PIN);

	PORTB |= (1 << TRIG_PIN);
	PORTB &= ~(1 << BUZZER_PIN);

	while (1)
	{
		unsigned int d = measure_distance_cm();
		unsigned int period = distance_to_period_ms(d);

		if (period == 0)
		{
			_delay_ms(100);
		}
		else
		{
			beep_once(period);
		}
	}
}