/*
 * Robot.c
 *
 * Created: 19/03/2026 17:15:52
 * Author : ZEBED
 */ 

#define F_CPU 20E6
#include <avr/io.h>
#include <avr/interrupt.h>
#include <string.h>
#include <stdio.h>
#include <util/delay.h>
#define Baud_Rate 9600UL
#define Baud_Register_Value ((F_CPU / (16 * Baud_Rate))-1)
#define Motor_1_PWM PD5				// Motor 1 PWM output on OC1A (PD5) - Speed control
#define Motor_2_PWM PD4				// Motor 2 PWM output on OC1A (PD5) - Speed control
#define DIR_1 PC0					// DIR1 (Motor 1 direction control) on PC0
#define DIR_2 PC1					// DIR1 (Motor 2 direction control) on PC1
#define IR_Left PD2					// IR sensor 1 is on PD2
#define IR_Right PD3				// IR sensor 2 is on PD3

volatile char Rx_Char = 'S';
int Go = 255;					// Sets PWM width - controlling motor speed
int stop = 0;


void forward()					// Set direction pins to move forwards
{
	PORTC |= 1<<DIR_1;
	PORTC &= ~(1<<DIR_2);
}

void backward()					// Set direction pins to move backwards
{
	PORTC |= 1<<DIR_2;
	PORTC &= ~(1<<DIR_1);
}

void left()						// Set direction pins to move left
{
	PORTC |= 1<<DIR_2;
	PORTC |= 1<<DIR_1;
}

void right()					// Set direction pins to move right
{
	PORTC &= ~(1<<DIR_2);
	PORTC &= ~(1<<DIR_1);
}

void manual_control()
{
	// Load Go PWM value for motor speed
	OCR1A = Go;
	OCR1B = Go;
	
	// Read received character, then move forwards, backwards, left or right.
	if (Rx_Char == 'F')
	{
		forward();
	}
	else if (Rx_Char == 'B')
	{
		backward();
	}
	else if (Rx_Char == 'L')
	{
		left();
	}
	else if (Rx_Char == 'R')
	{
		right();
	}
	else
	{
		// Anything other than a direction = stop robot
		OCR1A = stop;
		OCR1B = stop;
	}
}

void line_following()
{
	//
	OCR1A = Go;
	OCR1B = Go;
	if (!(PIND & (1<<IR_Left | 1<<IR_Right)))
	{
		// Load the width
		OCR1A = Go;
		OCR1B = Go;
		// Both IR sees black -> go forwards
		forward();
		
	}
	else if (!(PIND & (1<<IR_Left)))
	{
		// Load the width
		OCR1A = Go;
		OCR1B = Go;
		// Left = Black, Right = White, go left
		left();
	}
	else if (!(PIND & (1<<IR_Right)))
	{
		// Load the width
		OCR1A = Go;
		OCR1B = Go;
		// Left = White, Right = Black, go right
		right();
	}
	else if ((PIND & (1<<IR_Left | 1<<IR_Right)))
	{
		// Both sensors = white, stop
		OCR1A = stop;
		OCR1B = stop;
	}
}
int main(void)
{
	// Make control pins outputs
	DDRD = 1<<Motor_1_PWM | 1<<Motor_2_PWM;
	DDRC = 1<<DIR_1 | 1<<DIR_2;
	
	// Load the width
	OCR1A = 0;
	OCR1B = 0;
	
	// Settings for 8-bit fast PWM, COM1A1 and COM1B1 to non-inverting 
	TCCR1A = 1<<WGM10 | 1<<COM1A1 | 1<<COM1B1; 
	TCCR1B = 1<<WGM12 | 1<<CS10;
	
	UBRR0 = Baud_Register_Value;			// Set UART's baud to 9600 with F_CPU = 20 MHz
	UCSR0B = 1<<RXEN0 | 1<<RXCIE0;			// Receive enable, receive interrupt enable
	UCSR0C = 1<<UCSZ01 | 1<<UCSZ00;			// 8-bit data format

	sei();                                   // Enable global interrupts
	
	while (1)
	{
		
	}
}

ISR(USART0_RX_vect)
{
	Rx_Char = UDR0;
	// Z received = line following mode, anything else = manual control
	if (Rx_Char == 'Z')
	{
		line_following();
	}
	else
	{
		manual_control();
	}
}