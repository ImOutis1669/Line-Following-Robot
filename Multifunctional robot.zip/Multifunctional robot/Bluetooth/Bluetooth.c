/*
 * Bluetooth.c
 *
 * Created: 04/02/2026 11:28:19
 * Author : ZEBED
 */ 

#define F_CPU 20000000UL
#include <avr/io.h>

#define BAUD 38400UL
#define UBRR_VAL ((F_CPU/(16UL*BAUD))-1)

void usart0_init(void) {          // HC-05 side
	UBRR0H = UBRR_VAL >> 8;
	UBRR0L = UBRR_VAL;
	UCSR0C = (1<<UCSZ01)|(1<<UCSZ00);
	UCSR0B = (1<<RXEN0)|(1<<TXEN0);
}

void usart1_init(void) {          // PC side
	UBRR1H = UBRR_VAL >> 8;
	UBRR1L = UBRR_VAL;
	UCSR1C = (1<<UCSZ11)|(1<<UCSZ10);
	UCSR1B = (1<<RXEN1)|(1<<TXEN1);
}

static inline void u0_tx(char c){
	while(!(UCSR0A & (1<<UDRE0)));
	UDR0 = c;
}
static inline void u1_tx(char c){
	while(!(UCSR1A & (1<<UDRE1)));
	UDR1 = c;
}

int main(void)
{
	usart0_init();   // HC-05
	usart1_init();   // PC

	while(1){
		if(UCSR1A & (1<<RXC1)) u0_tx(UDR1); // PC ? HC-05
		if(UCSR0A & (1<<RXC0)) u1_tx(UDR0); // HC-05 ? PC
	}
}