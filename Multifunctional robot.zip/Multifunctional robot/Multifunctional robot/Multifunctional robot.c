/*
 * Multifunctional robot.c
 *
 * Created: 04/02/2026 09:49:50
 * Author : ZEBED
 */ 

#include <avr/io.h>


int main(void)
{
    /* Replace with your application code */
    while (1) 
    {
    }
}

