/*
 * Serial reception.c
 *
 * Created: 04/02/2026 09:51:03
 * Author : ZEBED
 */ 

#include <avr/io.h>
#include <avr/interrupt.h>
#include <string.h>
#include <stdio.h>
#define F_CPU 20E6
#define Baud_Rate 9600UL
#define Baud_Register_Value ((F_CPU / (16 * Baud_Rate))-1)
#define Red_LED PC0									// Red LED is on Port A, Pin 0
#define Green_LED PC1								// Green LED is on Port A, Pin 1
#define Blue_LED PC2								// Blue LED is on Port A, Pin 2
#define Yellow_LED PC3					// Yellow LED is on Port A, Pin 3

int main(void)
{
	UBRR0 = Baud_Register_Value;			// Set UART's baud to 9600 with F_CPU = 20 MHz
	UCSR0B = 1<<RXEN0 | 1<<RXCIE0;			// Receive enable, receive interrupt enable
	
	DDRC = 1<<Red_LED | 1<<Yellow_LED | 1<<Blue_LED | 1<<Green_LED;

	sei();                                   // Enable global interrupts
	
	while (1)
	{
	}
}

ISR(USART0_RX_vect)
{
	static char Rx_Char;					// Variable to store UART data
	Rx_Char = UDR0;							// Read UART data
	if (Rx_Char == 'F')
	{
		PORTC |= 1<<Green_LED;	
	}
	else if (Rx_Char == 'B')
	{
		PORTC |= 1<<Red_LED;
	}
	else if (Rx_Char == 'R')
	{
		PORTC |= 1<<Yellow_LED;
	}
	else if (Rx_Char == 'L')
	{
		PORTC |= 1<<Blue_LED;
	}
	else
	{
		PORTC &= ~(1<<Red_LED);
		PORTC &= ~(1<<Green_LED);
		PORTC &= ~(1<<Blue_LED);
		PORTC &= ~(1<<Yellow_LED);
	}
}