/*
 * Joystick y control.c
 *
 * Created: 18/02/2026 13:11:29
 * Author : ZEBED
 */ 

#define F_CPU 20E6
#include <avr/io.h>
#include <util/delay.h>
#define Motor_1_PWM PD5			// Motor 1 PWM output on OC1A (PD5) - Speed control
#define Motor_2_PWM PD4			// Motor 2 PWM output on OC1A (PD5) - Speed control
#define DIR_1 PC0				// DIR1 (Motor 1 direction control) on PC0
#define DIR_2 PC1				// DIR1 (Motor 2 direction control) on PC1

int Width = 255;				// Sets PWM width - controlling motor speed
int stop = 0;
volatile int ADC_Result; // Declaring ADC Result as volatile

int ADC_Conversion()  // ADC conversion function
{
	ADCSRA |= 1<<ADSC;         // ADSC (starts conversion) bit set
	while(ADCSRA & 1<<ADSC);   // As long as ADSC high, stay in while loop
	return(ADC);
}

void forward()
{
	PORTC |= 1<<DIR_1;
	PORTC &= ~(1<<DIR_2);
}

void backward()
{
	PORTC |= 1<<DIR_2;
	PORTC &= ~(1<<DIR_1);
}

void left()
{
	PORTC |= 1<<DIR_1;
	PORTC |= 1<<DIR_2;
}

void right()
{
	PORTC &= ~(1<<DIR_1);
	PORTC &= ~(1<<DIR_2);
}

int main(void)
{
	
	// ADC initialisation
	ADMUX = 1<<REFS0 | 1<<MUX1;              // Sets Reference voltage and input to the ADC
	ADCSRA = 1<<ADEN | 1<<ADPS0 | 1<<ADPS2;  // Enables ADC and sets prescale
	DIDR0 = 0xFF;                            // Sets register DIDR off
	
	// Make control pins outputs
	DDRD = 1<<Motor_1_PWM | 1<<Motor_2_PWM;
	DDRC = 1<<DIR_1 | 1<<DIR_2;
	
	// Load the width
	OCR1A = Width;
	OCR1B = Width;
	
	// Settings for 8-bit fast PWM, no prescale and set Blue LED to non-invertingPWM
	TCCR1A = 1<<WGM10 | 1<<COM1A1 | 1<<COM1B1; // sets COM1A1 to non inverting
	TCCR1B = 1<<WGM12 | 1<<CS10;

	while (1)
	{
		ADC_Conversion();				// Call ADC conversion
		ADC_Result = ADC_Conversion();	// Read the ADC
		if (ADC_Result > 600)
		{
			OCR1A = Width;
			OCR1B = Width;
			forward();
		}
		else if (ADC_Result < 450)
		{
			OCR1A = Width;
			OCR1B = Width;
			backward();
		}
		else
		{
			OCR1A = stop;
			OCR1B = stop;
		}
	}
}


