#define F_CPU 20000000UL
#include <avr/io.h>
#include <util/delay.h>
#include <stdint.h>

#define BAUD 38400UL
#define UBRR_VAL ((F_CPU/(16UL*BAUD))-1UL)

// NOTE: D3 LED is on the PCB; exact port pin can vary by board wiring.
// If this doesn't blink, we�ll remove it and focus purely on UART.
static inline void led_init_guess(void){
	// GUESS: many AVR lab boards put LED on PB0; harmless if wrong.
	DDRB |= (1<<PB0);
}
static inline void led_toggle_guess(void){
	PINB = (1<<PB0); // toggle if supported on that pin
}

static void usart0_init(void){
	UBRR0H = (uint8_t)(UBRR_VAL>>8);
	UBRR0L = (uint8_t)UBRR_VAL;
	UCSR0C = (1<<UCSZ01)|(1<<UCSZ00);      // 8N1
	UCSR0B = (1<<RXEN0)|(1<<TXEN0);        // RX/TX on
}

static inline void u0_tx(uint8_t c){
	while(!(UCSR0A & (1<<UDRE0)));
	UDR0 = c;
}

int main(void){
	led_init_guess();
	usart0_init();

	while(1){
		// heartbeat (ignore if LED pin guess is wrong)
		led_toggle_guess();
		_delay_ms(300);

		// echo
		if (UCSR0A & (1<<RXC0)) u0_tx(UDR0);
	}
}
